<?php
header('Content-Type: application/json'); // JSON 형식으로 응답을 보내기 위해 Content-Type을 설정합니다.

// 데이터베이스 연결 설정
$servername = "localhost";
$username = "pckiosk";
$password = "pipecoding0310!";
$dbname = "pckiosk";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// 연결 확인
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// POST 데이터 가져오기
$age = (int)$_POST['age'];

// INSERT INTO 쿼리 실행
$sql = "INSERT INTO pckiosk (id, age) VALUES (NULL, $age)";
if (mysqli_query($conn, $sql)) {
    $inserted_id = mysqli_insert_id($conn); // 새로 추가된 레코드의 id를 가져옵니다.
    $data = array('id' => $inserted_id, 'age' => $age);
    echo json_encode($data); // JSON 형식으로 데이터를 출력합니다.
} else {
    echo json_encode(array('error' => 'Insert failed.')); // JSON 형식으로 에러 메시지를 출력합니다.
}

// 데이터베이스 연결 종료
mysqli_close($conn);
?>





