package com.incava.kioskdevelopproject

data class UserAgeVO(
//    val id : Int,
    val age : Int
)
