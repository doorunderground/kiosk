package com.incava.kioskdevelopproject

import android.graphics.Rect
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.incava.kioskdevelopproject.databinding.MenuItemBinding

/**
 * 메뉴 recyclerView Adapter
 */
class MenuAdapter(private val dataList : MutableList<MenuVO>) : RecyclerView.Adapter<MenuAdapter.VH>() {



    class VH(private val binding: MenuItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(menuVo : MenuVO) {
            binding.apply {
                Glide.with(binding.root)
                    .load(menuVo.image)
                    .into(iv)
                tvMenu.text = menuVo.name
                tvPrice.text = "₩${menuVo.price}"
                tvRemark.text = menuVo.remark
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = MenuItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return VH(binding)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(dataList[position])

    }

    inner class VerticalSpaceItemDecoration(private val verticalSpaceHeight: Int) :
        RecyclerView.ItemDecoration() { // 아이템 마다 간격을 파라미터 만큼 띄울 수 있게 하는 클래스.

        override fun getItemOffsets(
            outRect: Rect, view: View, parent: RecyclerView,
            state: RecyclerView.State
        ) {
            outRect.bottom = verticalSpaceHeight
            outRect.right = verticalSpaceHeight
            outRect.left = verticalSpaceHeight
            outRect.top = verticalSpaceHeight
        }
    }

}