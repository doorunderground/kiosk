package com.incava.kioskdevelopproject

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import com.incava.kioskdevelopproject.databinding.FragmentSelectMenuBinding
import com.incava.kioskdevelopproject.databinding.FragmentSelectMenuExpendBinding

/**
 * 확대된 메뉴 fragment
 */
class SelectMenuExpendFragment : Fragment() {
    private var _binding: FragmentSelectMenuExpendBinding? = null
    private val binding get() = _binding!!
    private val datas = mutableListOf<MenuVO>() // 메뉴 리사이클러뷰에 담을 배열
    private lateinit var menuAdapter: MenuAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSelectMenuExpendBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var listManager = GridLayoutManager(activity, 1) // 열당 아이템 1개씩 보이도록 구현.
        addMenu()
        menuAdapter = MenuAdapter(datas)

        binding.rcv.apply { //아이템간 간격 조절
            addItemDecoration(menuAdapter.VerticalSpaceItemDecoration(20))
            layoutManager = listManager
            adapter = menuAdapter
        }

        binding.btnPrev.setOnClickListener {
            findNavController().navigate(R.id.action_selectMenuExpendFragment_to_selectMenuFragment)
        }
    }

    private fun addMenu(){
        datas.apply {
            add(MenuVO("아이스아메리카노",R.drawable.americano,3500,"Hot"))
            add(MenuVO("HOT_아메리카노",R.drawable.americano,3000,"Hot"))
            add(MenuVO("아이스카페라떼",R.drawable.americano,4000,"Hot"))
            add(MenuVO("HOT_카페라떼",R.drawable.americano,3500,"Hot"))
            add(MenuVO("카페 모카",R.drawable.americano,4000,"NEW!"))
            add(MenuVO("카푸치노",R.drawable.americano,4000,""))
            add(MenuVO("바닐라라떼",R.drawable.americano,3000,""))
            add(MenuVO("아이스티",R.drawable.americano,2500,""))
            add(MenuVO("녹차라떼",R.drawable.americano,4000,""))
            add(MenuVO("민트초코라떼",R.drawable.americano,4000,""))
            add(MenuVO("티라미슈라떼",R.drawable.americano,4000,""))
            add(MenuVO("에스프레소",R.drawable.americano,5000,""))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }



}