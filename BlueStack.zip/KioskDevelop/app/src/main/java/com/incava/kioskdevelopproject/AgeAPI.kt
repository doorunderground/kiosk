package com.incava.kioskdevelopproject

import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

/**
 * API interface
 */
interface AgeAPI {
        @FormUrlEncoded
        @POST("KioskInsert.php")
        fun setInsert(@Field("age") age: Int): Call<UserAgeVO> //Age를 Insert할 쿼리문 생성.

        @POST("KioskSelect.php")
        fun getAge(): Call<UserAgeVO>
    }