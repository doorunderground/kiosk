package com.incava.kioskdevelopproject


/**
 * MenuRecyclerView 의 dataclass
 */
data class MenuVO(
    val name : String,//메뉴이름
    val image : Int, // 원랜 uri이 맞을 거같지만 지금은 이미지가 리소스로 있으므로
    val price : Int, // 메뉴 가격
    val remark : String, // 메뉴 비고
)
