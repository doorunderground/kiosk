package com.incava.kioskdevelopproject

import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import com.incava.kioskdevelopproject.databinding.DialogExpendBinding
import com.incava.kioskdevelopproject.databinding.FragmentSelectMenuBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.random.Random

/**
 * 메뉴를 고를 수 있는 fragment
 */
class SelectMenuFragment : Fragment() {
    private var _binding: FragmentSelectMenuBinding? = null
    private val binding get() = _binding!!
    val datas = mutableListOf<MenuVO>() // 메뉴 리사이클러뷰에 담을 배열
    private lateinit var menuAdapter: MenuAdapter
    private lateinit var dialog: AlertDialog
    private lateinit var expendBinding : DialogExpendBinding
    private var requestThread = RequestThread()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSelectMenuBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        expendBinding = DialogExpendBinding.inflate(layoutInflater,null,false)
        val builder = AlertDialog.Builder(activity)
            .setView(expendBinding.root)
            .setCancelable(false) // 밖에눌러도 안꺼지도록 false
        dialog = builder.create()
        var listManager = GridLayoutManager(activity, 4) // 4개의 열로 RecyclerManager set
        addMenu()
        menuAdapter = MenuAdapter(datas)

        binding.rcv.apply {// 아이템 간격 설정.
            addItemDecoration(menuAdapter.VerticalSpaceItemDecoration(20))
            layoutManager = listManager
            adapter = menuAdapter
            hasFixedSize()
        }
        binding.btnExpend.setOnClickListener { expendRequest() } // 확대 버튼 누르면  dialog를 띄우는 클릭리스너 연결.
        //requestThread = RequestThread() // 객체 생성.
        requestThread.start()
    }

    inner class RequestThread : Thread() { // db에서 age값 읽어와 dialog 띄우기.
        var isRun = true
        override fun run() {
            while (isRun){
                if(!dialog.isShowing){
//                    insertAgePhp() // db Insert
                    sleep(3000)
                    getAgePhp() // db select
                }
                else{ // dialog가 켜져 있을 경우 5초 쉬고 쓰레드 돌리기.
                    Log.i("dialog",dialog.isShowing.toString())
                }
                sleep(3000)
            }
        }
    }

    private fun insertAgePhp() {
        val requests = RetrofitClient.getInstance().create(AgeAPI::class.java) //API Request할 Retrofit객체 생성.
        requests.setInsert(Random.nextInt(100)).enqueue(object : Callback<UserAgeVO> {//100이하의 랜덤 숫자를 넣어줌.
            override fun onResponse(call: Call<UserAgeVO>, response: Response<UserAgeVO>) {
                if (response.isSuccessful) {
                    val data = response.body()
                    Log.d("KioskData", "Insert success. Age: ${data?.age}")
                } else {
                    Log.e("KioskData", "Insert failed. Response code: ${response.code()}")
                }
            }
            override fun onFailure(call: Call<UserAgeVO>, t: Throwable) {
                Log.e("KioskData", "Insert failed. ${t.message}")
            }
        })
    }

    private fun getAgePhp(){
        val request = RetrofitClient.getInstance().create(AgeAPI::class.java)
        request.getAge().enqueue(object : Callback<UserAgeVO> {
            override fun onResponse(call: Call<UserAgeVO>, response: Response<UserAgeVO>) {
                if (response.isSuccessful) {
                    val data = response.body()
                    Log.d("KioskData", "Get success. Age: ${data?.age}")
                    if (data != null) {
                        Toast.makeText(activity,"${data.age}",Toast.LENGTH_SHORT).show()
                        if (data.age>=24){ // 가져온 최근 나이가 60살 이상이면,
                            expendRequest() //dialog 띄우기.
                        }
                    }
                } else {
                    Log.e("KioskData", "Get failed. Response code: ${response.code()}")
                }
            }
            override fun onFailure(call: Call<UserAgeVO>, t: Throwable) {
                Log.e("KioskData", "Get failed. ${t.message}")
            }
        })
    }




    private fun addMenu(){
        datas.apply {
            add(MenuVO("아이스아메리카노",R.drawable.americano,3500,"Hot"))
            add(MenuVO("HOT_아메리카노",R.drawable.americano,3000,"Hot"))
            add(MenuVO("아이스카페라떼",R.drawable.americano,4000,"Hot"))
            add(MenuVO("HOT_카페라떼",R.drawable.americano,3500,"Hot"))
            add(MenuVO("카페 모카",R.drawable.americano,4000,"NEW!"))
            add(MenuVO("카푸치노",R.drawable.americano,4000,""))
            add(MenuVO("바닐라라떼",R.drawable.americano,3000,""))
            add(MenuVO("아이스티",R.drawable.americano,2500,""))
            add(MenuVO("녹차라떼",R.drawable.americano,4000,""))
            add(MenuVO("민트초코라떼",R.drawable.americano,4000,""))
            add(MenuVO("티라미슈라떼",R.drawable.americano,4000,""))
            add(MenuVO("에스프레소",R.drawable.americano,5000,""))
        }
    }
    private fun expendRequest() {
        dialog.show()
        expendBinding.btnPositive.setOnClickListener{
            findNavController().navigate(R.id.action_selectMenuFragment_to_selectMenuExpendFragment)
            //만약 확대를 원하는 다른 fragment로 이동. popUpTo로 navHost인 자신을 지우고 이동하여 자신을 첫번째 스택으로 만듦.
            dialog.dismiss()
        }
        expendBinding.btnNegative.setOnClickListener{ // 취소 버튼 누르면 dismiss
            dialog.dismiss()
        }
    }



    override fun onDestroy() {
        super.onDestroy()
        requestThread.isRun = false
        _binding = null
    }



}