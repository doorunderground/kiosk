<?php
// 데이터베이스 연결 설정
$servername = "localhost"; 
$username = "root";
$password = "5531";
$dbname = "db2";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// 연결 확인
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// 쿼리 실행 제일 최신 값의 age를 반환.
$sql = "SELECT * FROM `age` ORDER BY age DESC LIMIT 1;";
$result = mysqli_query($conn, $sql);

// 결과를 JSON 형식으로 변환
if (mysqli_num_rows($result) > 0) { // 1개밖에안와서 if로 처리.
    $row = mysqli_fetch_assoc($result);
    $json_response = json_encode($row);
    echo $json_response;
} else {
    echo "0 results";
}

// 데이터베이스 연결 종료
mysqli_close($conn);
?>
